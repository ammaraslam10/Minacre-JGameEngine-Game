public interface Interact {
    abstract boolean interact();
}
